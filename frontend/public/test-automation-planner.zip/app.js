// LLM Test Automation Prototype Planner JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application
    initializeTabs();
    initializePlanningSteps();
    initializePrototypeForm();
    
    // Add some debug logging
    console.log('LLM Test Automation Prototype Planner initialized');
});

// Tab Navigation
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');

    console.log('Initializing tabs:', tabButtons.length, 'buttons,', tabPanes.length, 'panes');

    tabButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const targetTab = this.getAttribute('data-tab');
            
            console.log('Switching to tab:', targetTab);
            
            // Remove active class from all tabs and panes
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanes.forEach(pane => {
                pane.classList.remove('active');
                pane.style.display = 'none';
            });
            
            // Add active class to clicked tab and corresponding pane
            this.classList.add('active');
            const targetPane = document.getElementById(targetTab);
            if (targetPane) {
                targetPane.classList.add('active');
                targetPane.style.display = 'block';
                
                // Trigger any specific initialization for the tab
                if (targetTab === 'planning') {
                    updateProgress();
                }
            } else {
                console.error('Target pane not found:', targetTab);
            }
        });
    });

    // Ensure initial tab is properly displayed
    const activeTab = document.querySelector('.tab-pane.active');
    if (activeTab) {
        activeTab.style.display = 'block';
    }
}

// Planning Steps Progress Tracking
function initializePlanningSteps() {
    const stepCheckboxes = document.querySelectorAll('.step-checkbox');
    const taskCheckboxes = document.querySelectorAll('.task-checkbox');
    
    console.log('Initializing planning steps:', stepCheckboxes.length, 'steps,', taskCheckboxes.length, 'tasks');

    // Update progress when step checkboxes change
    stepCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            console.log('Step checkbox changed:', this.id, this.checked);
            updateProgress();
        });
    });

    // Update progress when task checkboxes change
    taskCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            console.log('Task checkbox changed:', this.checked);
            updateTaskProgress(this);
            updateProgress();
        });
    });

    function updateTaskProgress(changedCheckbox) {
        const stepCard = changedCheckbox.closest('.step-card');
        if (!stepCard) return;
        
        const stepCheckbox = stepCard.querySelector('.step-checkbox');
        const taskCheckboxes = stepCard.querySelectorAll('.task-checkbox');
        
        const completedTasks = Array.from(taskCheckboxes).filter(cb => cb.checked).length;
        const totalTasks = taskCheckboxes.length;
        
        console.log('Step progress:', completedTasks, '/', totalTasks);
        
        // Auto-check step if all tasks are completed
        if (completedTasks === totalTasks && totalTasks > 0) {
            stepCheckbox.checked = true;
        } else if (completedTasks === 0) {
            stepCheckbox.checked = false;
        }
        
        // Update visual indication
        if (completedTasks === totalTasks && totalTasks > 0) {
            stepCard.style.borderColor = 'var(--color-success)';
            stepCard.style.backgroundColor = 'rgba(var(--color-success-rgb), 0.05)';
        } else if (completedTasks > 0) {
            stepCard.style.borderColor = 'var(--color-warning)';
            stepCard.style.backgroundColor = 'rgba(var(--color-warning-rgb), 0.05)';
        } else {
            stepCard.style.borderColor = 'var(--color-card-border)';
            stepCard.style.backgroundColor = 'var(--color-surface)';
        }
    }

    // Initialize progress on load
    setTimeout(updateProgress, 100);
}

function updateProgress() {
    const stepCheckboxes = document.querySelectorAll('.step-checkbox');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    
    if (!progressFill || !progressText) {
        console.warn('Progress elements not found');
        return;
    }
    
    const totalSteps = stepCheckboxes.length;
    const completedSteps = Array.from(stepCheckboxes).filter(cb => cb.checked).length;
    const progressPercentage = totalSteps > 0 ? (completedSteps / totalSteps) * 100 : 0;
    
    console.log('Progress update:', completedSteps, '/', totalSteps, '=', progressPercentage + '%');
    
    progressFill.style.width = progressPercentage + '%';
    progressText.textContent = Math.round(progressPercentage) + '% Complete';
    
    // Add celebration effect when 100% complete
    if (progressPercentage === 100) {
        progressText.textContent = '🎉 100% Complete - Ready to build your prototype!';
        progressText.style.color = 'var(--color-success)';
        progressText.style.fontWeight = 'var(--font-weight-bold)';
    } else {
        progressText.style.color = 'var(--color-text)';
        progressText.style.fontWeight = 'var(--font-weight-normal)';
    }
}

// Prototype Builder Form
function initializePrototypeForm() {
    const form = document.getElementById('prototypeForm');
    const clearButton = document.getElementById('clearForm');
    const generatedPlan = document.getElementById('generatedPlan');
    const planContent = document.getElementById('planContent');
    const downloadButton = document.getElementById('downloadPlan');
    const editButton = document.getElementById('editPlan');

    if (!form) {
        console.error('Prototype form not found');
        return;
    }

    console.log('Initializing prototype form');

    // Ensure all form fields are properly initialized
    const formInputs = form.querySelectorAll('input, textarea, select');
    formInputs.forEach(input => {
        // Remove any potential interference
        input.style.pointerEvents = 'auto';
        input.disabled = false;
        
        // Add event listeners for validation
        input.addEventListener('focus', function() {
            this.classList.remove('error');
        });
        
        input.addEventListener('blur', function() {
            if (this.hasAttribute('required') && !this.value.trim()) {
                this.classList.add('error');
            } else {
                this.classList.remove('error');
                this.classList.add('success');
            }
        });
    });

    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        console.log('Form submitted');
        
        if (validateForm()) {
            const formData = collectFormData();
            console.log('Form data collected:', formData);
            const plan = generatePrototypePlan(formData);
            displayGeneratedPlan(plan);
        }
    });

    // Clear form
    if (clearButton) {
        clearButton.addEventListener('click', function() {
            if (confirm('Are you sure you want to clear all form data?')) {
                form.reset();
                // Remove validation classes
                const formInputs = form.querySelectorAll('input, textarea, select');
                formInputs.forEach(input => {
                    input.classList.remove('error', 'success');
                });
                if (generatedPlan) {
                    generatedPlan.style.display = 'none';
                }
            }
        });
    }

    // Download plan
    if (downloadButton) {
        downloadButton.addEventListener('click', function() {
            if (planContent) {
                const planText = planContent.textContent;
                downloadTextFile(planText, 'llm-test-automation-prototype-plan.txt');
            }
        });
    }

    // Edit plan
    if (editButton) {
        editButton.addEventListener('click', function() {
            if (generatedPlan) {
                generatedPlan.style.display = 'none';
            }
            const firstInput = form.querySelector('input[type="text"]');
            if (firstInput) {
                firstInput.focus();
            }
        });
    }

    function validateForm() {
        const requiredFields = form.querySelectorAll('[required]');
        let isValid = true;
        let firstInvalidField = null;

        console.log('Validating form, required fields:', requiredFields.length);

        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                field.classList.add('error');
                field.classList.remove('success');
                isValid = false;
                if (!firstInvalidField) {
                    firstInvalidField = field;
                }
            } else {
                field.classList.remove('error');
                field.classList.add('success');
            }
        });

        if (!isValid && firstInvalidField) {
            firstInvalidField.focus();
            firstInvalidField.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // Show a user-friendly error message
            showNotification('Please fill in all required fields marked with *', 'error');
        }

        console.log('Form validation result:', isValid);
        return isValid;
    }

    function collectFormData() {
        const data = {};

        // Collect basic form data
        data.projectName = document.getElementById('projectName')?.value || '';
        data.description = document.getElementById('description')?.value || '';
        data.objectives = document.getElementById('objectives')?.value || '';
        data.llmModel = document.getElementById('llmModel')?.value || '';
        data.framework = document.getElementById('framework')?.value || '';
        data.language = document.getElementById('language')?.value || '';
        data.coverageGoal = document.getElementById('coverageGoal')?.value || '';
        data.timeline = document.getElementById('timeline')?.value || '';
        data.successMetrics = document.getElementById('successMetrics')?.value || '';

        // Collect test types
        const testTypeCheckboxes = document.querySelectorAll('input[name="testTypes"]:checked');
        data.testTypes = Array.from(testTypeCheckboxes).map(cb => cb.value);

        console.log('Collected form data:', data);
        return data;
    }

    function generatePrototypePlan(data) {
        const currentDate = new Date().toLocaleDateString();
        
        return `LLM TEST AUTOMATION PROTOTYPE PLAN
Generated on: ${currentDate}

═══════════════════════════════════════════════════════════════════

PROJECT INFORMATION
═══════════════════════════════════════════════════════════════════

Project Name: ${data.projectName}

Description:
${data.description}

Objectives:
${data.objectives}

═══════════════════════════════════════════════════════════════════

TECHNOLOGY STACK
═══════════════════════════════════════════════════════════════════

LLM Model: ${data.llmModel}
Testing Framework: ${data.framework}
Programming Language: ${data.language}

═══════════════════════════════════════════════════════════════════

SCOPE DEFINITION
═══════════════════════════════════════════════════════════════════

Types of Testing:
${data.testTypes && data.testTypes.length > 0 ? data.testTypes.map(type => `• ${type.charAt(0).toUpperCase() + type.slice(1)} Testing`).join('\n') : '• Not specified'}

Code Coverage Goal: ${data.coverageGoal ? data.coverageGoal + '%' : 'Not specified'}

═══════════════════════════════════════════════════════════════════

IMPLEMENTATION ROADMAP
═══════════════════════════════════════════════════════════════════

Timeline: ${data.timeline}

Phase 1: Setup & Planning (Week 1-2)
• Set up development environment
• Configure ${data.llmModel} API access
• Install ${data.framework} testing framework
• Prepare project structure in ${data.language}

Phase 2: LLM Integration (Week 3-4)
• Develop LLM integration layer
• Create prompt templates for test generation
• Implement natural language processing pipeline
• Test basic LLM connectivity and responses

Phase 3: Test Generation Engine (Week 5-6)
• Build test case generation module
• Implement test data creation algorithms
• Develop test script automation
${data.testTypes && data.testTypes.length > 0 ? data.testTypes.map(type => `• Create ${type} test generators`).join('\n') : ''}

Phase 4: Execution & Validation (Week 7-8)
• Implement test execution engine
• Build result validation system
• Create reporting dashboard
${data.coverageGoal ? `• Implement code coverage tracking (target: ${data.coverageGoal}%)` : ''}

Phase 5: Integration & Optimization (Week 9-10)
• Integrate with CI/CD pipeline
• Optimize LLM prompts for better accuracy
• Performance tuning and error handling
• User interface development

Phase 6: Testing & Refinement (Week 11-12)
• Comprehensive system testing
• User acceptance testing
• Documentation creation
• Final optimizations

═══════════════════════════════════════════════════════════════════

SUCCESS CRITERIA
═══════════════════════════════════════════════════════════════════

${data.successMetrics}

Key Performance Indicators:
• Test generation speed: Target 10x faster than manual creation  
• Test coverage improvement: ${data.coverageGoal ? `Target ${data.coverageGoal}%` : 'To be defined'}
• Defect detection rate: Baseline vs. LLM-generated tests
• Development time reduction: Measure time saved
• Code quality metrics: Maintainability and reliability

═══════════════════════════════════════════════════════════════════

RISK MITIGATION
═══════════════════════════════════════════════════════════════════

Technical Risks:
• LLM API rate limits and costs
• Generated test quality and reliability  
• Integration complexity with existing systems

Mitigation Strategies:
• Implement caching and batching for LLM requests
• Create validation layers for generated tests
• Develop fallback mechanisms for critical paths
• Regular quality audits of generated test cases

═══════════════════════════════════════════════════════════════════

RESOURCE REQUIREMENTS
═══════════════════════════════════════════════════════════════════

Team:
• 1 LLM/AI Engineer
• 1 Test Automation Engineer
• 1 Software Developer
• 1 QA Lead (part-time)

Tools & Services:
• ${data.llmModel} API subscription
• ${data.framework} testing framework license
• Cloud infrastructure for execution
• CI/CD pipeline setup
• Code coverage tools

Budget Considerations:
• LLM API costs (estimate based on usage)
• Development tools and licenses
• Cloud infrastructure costs
• Team time and resources

═══════════════════════════════════════════════════════════════════

NEXT STEPS
═══════════════════════════════════════════════════════════════════

Immediate Actions:
1. Secure budget approval and resources
2. Set up development environment
3. Obtain ${data.llmModel} API access
4. Assemble project team
5. Create detailed project timeline
6. Begin Phase 1 implementation

Review Milestones:
• Weekly progress reviews
• Bi-weekly stakeholder updates
• Monthly ROI assessments
• Quarterly strategy reviews

═══════════════════════════════════════════════════════════════════

This prototype plan serves as a comprehensive guide for implementing 
your LLM-based test automation solution. Regular reviews and 
adjustments should be made based on progress and learnings.

For additional support and resources, refer to the Resources tab
in the LLM Test Automation Prototype Planner.

═══════════════════════════════════════════════════════════════════`;
    }

    function displayGeneratedPlan(plan) {
        if (planContent && generatedPlan) {
            planContent.textContent = plan;
            generatedPlan.style.display = 'block';
            generatedPlan.scrollIntoView({ behavior: 'smooth' });
            
            showNotification('Prototype plan generated successfully!', 'success');
        }
    }

    function downloadTextFile(content, filename) {
        try {
            const blob = new Blob([content], { type: 'text/plain' });
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);
            
            showNotification('Plan downloaded successfully!', 'success');
        } catch (error) {
            console.error('Download failed:', error);
            showNotification('Download failed. Please try again.', 'error');
        }
    }
}

// Utility Functions
function showNotification(message, type = 'info') {
    // Remove any existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(n => n.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 16px 20px;
        background-color: var(--color-surface);
        border: 1px solid var(--color-border);
        border-radius: var(--radius-base);
        box-shadow: var(--shadow-lg);
        z-index: 1000;
        max-width: 400px;
        transform: translateX(100%);
        transition: transform var(--duration-normal) var(--ease-standard);
        font-family: var(--font-family-base);
        font-size: var(--font-size-sm);
    `;
    
    if (type === 'success') {
        notification.style.borderLeftColor = 'var(--color-success)';
        notification.style.borderLeftWidth = '4px';
    } else if (type === 'error') {
        notification.style.borderLeftColor = 'var(--color-error)';
        notification.style.borderLeftWidth = '4px';
    }
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

// Add smooth scrolling for internal links
document.addEventListener('click', function(e) {
    if (e.target.matches('a[href^="#"]')) {
        e.preventDefault();
        const targetId = e.target.getAttribute('href').substring(1);
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
            targetElement.scrollIntoView({ behavior: 'smooth' });
        }
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + 1-4 for tab navigation
    if ((e.ctrlKey || e.metaKey) && e.key >= '1' && e.key <= '4') {
        e.preventDefault();
        const tabIndex = parseInt(e.key) - 1;
        const tabButtons = document.querySelectorAll('.tab-btn');
        if (tabButtons[tabIndex]) {
            tabButtons[tabIndex].click();
        }
    }
    
    // Escape to close generated plan
    if (e.key === 'Escape') {
        const generatedPlan = document.getElementById('generatedPlan');
        if (generatedPlan && generatedPlan.style.display !== 'none') {
            generatedPlan.style.display = 'none';
        }
    }
});

// Export functionality for study materials
function initializeExportFeatures() {
    const resourceSection = document.querySelector('#resources .section');
    if (resourceSection) {
        const exportButton = document.createElement('button');
        exportButton.className = 'btn btn--secondary';
        exportButton.textContent = 'Export Resource List';
        exportButton.style.marginTop = 'var(--space-16)';
        
        exportButton.addEventListener('click', function() {
            exportResourceList();
        });
        
        resourceSection.appendChild(exportButton);
    }
}

function exportResourceList() {
    const resources = {
        videos: [
            { title: "Software Testing Full Course", duration: "10 hours", provider: "Edureka" },
            { title: "What is Software Testing", duration: "15 minutes", provider: "Software Testing Mentor" },
            { title: "Automation Testing Tutorial", duration: "Various", provider: "Multiple sources" }
        ],
        courses: [
            { title: "Complete Software Testing Bootcamp", provider: "Udemy", level: "Beginner to Advanced" },
            { title: "Test Automation Engineer Masters", provider: "Edureka", level: "Advanced" },
            { title: "Automated Testing for LLMOps", provider: "DeepLearning.AI", level: "Intermediate" }
        ],
        tools: [
            { name: "Selenium", type: "Web Automation", language: "Multiple" },
            { name: "Cypress", type: "Web Automation", language: "JavaScript" },
            { name: "Postman", type: "API Testing", language: "JavaScript" },
            { name: "JaCoCo", type: "Code Coverage", language: "Java" },
            { name: "OpenAI API", type: "LLM Integration", language: "Multiple" }
        ]
    };
    
    let resourceText = "LLM TEST AUTOMATION LEARNING RESOURCES\n";
    resourceText += "=" + "=".repeat(50) + "\n\n";
    
    resourceText += "VIDEO TUTORIALS:\n";
    resourceText += "-".repeat(20) + "\n";
    resources.videos.forEach(video => {
        resourceText += `• ${video.title}\n`;
        resourceText += `  Duration: ${video.duration}\n`;
        resourceText += `  Provider: ${video.provider}\n\n`;
    });
    
    resourceText += "ONLINE COURSES:\n";
    resourceText += "-".repeat(20) + "\n";
    resources.courses.forEach(course => {
        resourceText += `• ${course.title}\n`;
        resourceText += `  Provider: ${course.provider}\n`;
        resourceText += `  Level: ${course.level}\n\n`;
    });
    
    resourceText += "TOOLS & FRAMEWORKS:\n";
    resourceText += "-".repeat(25) + "\n";
    resources.tools.forEach(tool => {
        resourceText += `• ${tool.name} (${tool.type}) - ${tool.language}\n`;
    });
    
    try {
        const blob = new Blob([resourceText], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'llm-test-automation-resources.txt';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        
        showNotification('Resource list exported successfully!', 'success');
    } catch (error) {
        console.error('Export failed:', error);
        showNotification('Export failed. Please try again.', 'error');
    }
}

// Initialize export features when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Delay initialization to ensure all elements are properly loaded
    setTimeout(() => {
        initializeExportFeatures();
        console.log('All features initialized successfully');
    }, 500);
});

// Add debugging for form elements
window.debugForm = function() {
    const form = document.getElementById('prototypeForm');
    if (form) {
        const inputs = form.querySelectorAll('input, textarea, select');
        console.log('Form elements found:', inputs.length);
        inputs.forEach((input, index) => {
            console.log(`${index + 1}. ${input.tagName} #${input.id} - disabled: ${input.disabled}, readOnly: ${input.readOnly}`);
        });
    } else {
        console.log('Form not found');
    }
};